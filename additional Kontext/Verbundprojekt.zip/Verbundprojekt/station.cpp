#include "station.h"

Station::Station(int id) : P1(id+1), P2(id+2)
{
    ID = id;
}
